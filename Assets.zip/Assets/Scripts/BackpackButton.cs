using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BackpackButton : MonoBehaviour
{
    public GameObject backpackObject;
    public GameObject itemPrefab;
    public int itemId;
    public GameObject Item;

    public void OnClick()
    {
        GameObject newItem;
        newItem = Instantiate(itemPrefab, backpackObject.transform);
        Item.SetActive(false);
        //itemPrefab.SetActive(true);
    }
}