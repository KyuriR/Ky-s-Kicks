using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.UI;

public class ButtonInfo : MonoBehaviour
{
    public GameObject panelObject;
    public GameObject itemPrefab;
    public GameObject OGItem;
    public int itemID;
    public int maxItems = 6; 
    private int currentItemCount = 0; 
    public ShopManager shopManager; 

    public void OnClick()
    {
        if (currentItemCount < maxItems)
        {
            // Check if there is enough money to buy the item
            if (shopManager.CanBuy(itemID))
            {
                shopManager.Buy(itemID); // Perform the purchase
                GameObject newItem = Instantiate(itemPrefab, panelObject.transform);
                OGItem.SetActive(false);
                itemPrefab.SetActive(true);
                currentItemCount++;
            }
            else
            {
                Debug.Log("Not enough money to buy this item.");
            }
        }
        else
        {
            Debug.Log("Backpack is full.");
        }
    }
}
