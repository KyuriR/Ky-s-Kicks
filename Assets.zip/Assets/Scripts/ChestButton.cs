using System.Buffers.Text;
using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;





public class ChestButton : MonoBehaviour
{
    public GameObject chestObject;
    public GameObject itemPrefab;
    public GameObject Item;
    public int itemID;

    public void OnClick()
    {
        GameObject newItem;
        newItem = Instantiate(itemPrefab, chestObject.transform);
        Item.SetActive(false);
        //itemPrefab.SetActive(true);

    }
}