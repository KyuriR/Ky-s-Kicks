using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoToShop : MonoBehaviour
{

    public ShopManager shopManager; // Reference to ShopManager component
    public RectTransform shopPanel; // Reference to the RectTransform of the shop panel (assign in Inspector)
    public Vector3 backpackChestPosition = new Vector3(500f, -490f, 0f); // Position
    public Vector2 originalPosition; // Original position of the shop panel (set in Inspector)


    public void MoveToOriginal()
    {
        shopPanel.anchoredPosition = originalPosition;
        Debug.Log("MoveToOriginal --- ");
        //shopManager.ShowBackpackChest(false); // Call ShopManager method to update UI elements (optional)
    }
}