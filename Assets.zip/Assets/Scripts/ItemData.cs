﻿public class ItemData
{
    public float price;
    public float id;
    public float quantity;

    public ItemData(float id, float price = 0, int quantity = 0 )
    {
        this.id = id;
        this.price = price;
        this.quantity = quantity;
    }

    public int V1 { get; }
    public int V2 { get; }
}