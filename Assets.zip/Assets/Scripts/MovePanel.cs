using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePanel : MonoBehaviour
{
    public ShopManager shopManager; // Reference to ShopManager component
    public RectTransform shopPanel; // Reference to the RectTransform of the shop panel (assign in Inspector)
    public Vector3 backpackChestPosition = new Vector3(300f, -200f, 0f); // Position
    public Vector2 originalPosition; // Original position of the shop panel (set in Inspector)

    public void MoveToChest()
    {
        shopPanel.anchoredPosition = backpackChestPosition;
        //shopManager.ShowBackpackChest(true); // Call ShopManager method to update UI elements (optional)
    }

}
