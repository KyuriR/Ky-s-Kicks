using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelManager : MonoBehaviour
{
    //public Transform Backpack; 
    //public int maxItems = 6;
    //public List<shopItems> shopItems;

    //public void AddToBackpack(Transform backpack)
    //{
    //    if (shopItems >= maxItems)
    //    {

    //    }
    //}
}
