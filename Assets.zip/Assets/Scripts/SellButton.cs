using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SellButton : MonoBehaviour

{

    public GameObject panelObject;
    public GameObject itemPrefab;
    public GameObject OGItem;
    public int itemID;

    public void OnClick()
    {

        GameObject newItem;
        newItem = Instantiate(itemPrefab, panelObject.transform);
        OGItem.SetActive(false);
        itemPrefab.SetActive(true);
    }
}