using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SpecialItems : MonoBehaviour
{

    public GameObject shopObject;
    public GameObject itemPrefab;
    public GameObject Item;
    public int itemID;
    public GameObject specialItem;
    public void OnClick()

    {
       
         
        specialItem.SetActive(true);
            GameObject newItem;
            newItem = Instantiate(itemPrefab, shopObject.transform);

            Item.SetActive(false);
        
       // itemPrefab.SetActive(true);
    }
}