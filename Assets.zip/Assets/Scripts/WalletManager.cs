using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;



public class WalletManager : MonoBehaviour
{
    
    public Text moneyTxt;
    public GameObject itemPrefab;
    public GameObject backpackPanel;

    public ItemData[] shopItems;
    public float money = 100;
    public GameObject shopObject;
    public GameObject Item;


    public void Start()
    {
        moneyTxt.text = "Money:$" + money.ToString();

        shopItems = new ItemData[12];

        shopItems = new ItemData[12];
        shopItems[0] = new ItemData(1, 15);
        shopItems[1] = new ItemData(2, 10);
        shopItems[2] = new ItemData(3, 8);
        shopItems[3] = new ItemData(4, 12);
        shopItems[4] = new ItemData(5, 17);
        shopItems[5] = new ItemData(6, 7);
        shopItems[6] = new ItemData(7, 13);
        shopItems[7] = new ItemData(8, 9);
        shopItems[8] = new ItemData(9, 6);
        shopItems[9] = new ItemData(10, 30);
        shopItems[10] = new ItemData(11, 25);
        shopItems[11] = new ItemData(12, 20);
    }

    public void Buy(int itemIndex) 
    {
        float price = shopItems[itemIndex].price;

        if (money >= price)
        {
            money -= price;
            moneyTxt.text = "MONEY:$" + money.ToString();
            
        }
        else
        {
            
            Debug.LogError("Insufficient Funds! You need $" + price + " to buy this item.");
        }
    }

    public void Sell(int itemIndex)
    {
        money += shopItems[itemIndex].price;
        moneyTxt.text = "MONEY:$" + money.ToString();

    }

    public void OnClick()
    {
        GameObject newItem;
        newItem = Instantiate(itemPrefab, shopObject.transform);
        Destroy(Item);
    }
}
